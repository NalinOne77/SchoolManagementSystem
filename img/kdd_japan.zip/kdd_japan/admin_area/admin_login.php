<?php
ob_start();
include '../classes/Adminlogin.php';

?>
<?php
    $al = new Adminlogin();
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $adminUsername = $_POST['adminUsername'];
    $adminPassword = md5($_POST['adminPassword']);

    $signin = $al->adminLogin($adminUsername,$adminPassword); 
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin Area | Login</title>
       <!--google-font-->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
      <link href="css/adminlogin.css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" type="text/css" href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css">
      <link href="../css/animate.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="wow fadeIn">
         <div class="grad"></div>
      <div class="header">
          <center><small class="welcometxt">Welcome to</small><small class="admintxt">Admin Area</small></center> 
      </div>
  <?php if(isset($signin)){echo $signin;}?>

      
      <div class="container">
		<div class="login-box">
			<div class="box-header">
				<h2>Log In</h2>
                
			</div>
            <form action="admin_login.php"  method="post">
                 <i class="log-icon fa fa-user-circle-o fa-2x" aria-hidden="true"></i>
                <input type="text" name="adminUsername" placeholder="Username">
                
			<br/>
                <i class="log-icon fa fa-unlock fa-2x" aria-hidden="true"></i>
                <input type="password" name="adminPassword" placeholder="Password">
                <br/>
                  
			<br/>
              
			 <button type="submit" class="button btn-lg btn-success">Sign In</button>
			<br/>
            </form>
		</div>
	</div>   
     <!-- <footer id="footer">
        <small>Copyright K.D.T. Japan, &copy; 2017</small>
      </footer>
      -->
       <!--WOW.js-->
    <script src="../js/wow.min.js"></script>
    <script>new WOW().init();</script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script type="text/JavaScript" src="js/javascript.js"></script>
       <script>
       window.setTimeout(function() {
    $("#logalert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 4000);
      </script>
  </body>
</html>
