<?php
ob_start();
    include '../lib/Session.php';
    include '../classes/DiskStatus.php';
    Session::checkSession();
    include '../classes/User.php';
    include '../classes/Vehicle.php';
    include '../classes/SparePart.php';
    include '../classes/Brand.php';
?>
<?php
try {
  $diskStatus = new DiskStatus('c:');

  $freeSpace = $diskStatus->freeSpace();
  $totalSpace = $diskStatus->totalSpace();
  $barWidth = ($diskStatus->usedSpace()/100) * 400;

} catch (Exception $e) {
  echo 'Error ('.$e->getMessage().')';
  exit();
}
?>
<?php
$user = new User();
$vehi = new Vehicle();
$sp = new SparePart();
$br = new Brand();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Admin Area | Dashborad</title>
      <!--google-font-->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow" rel="stylesheet">
      <script src="http://code.highcharts.com/highcharts.js"></script>
      <script src="js/Chart.min.js" type="text/javascript"></script>
      <script src="js/modernizr.js" type="text/javascript"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" >
      <link  href="css/style.css" rel="stylesheet">
      <link href="../css/animate.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css">
      
  </head>
  <body>
      
      <?php
        include'header.php'
      ?>
      
      <section id="main">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="list-group">
                        <div class="header main-color">Dashboard Menu</div>
                        <div style="background-color:white;margin-bottom:-10px">
                            <br>
                            <div  align="center"><img alt="User Pic" src="../images/User.jpg" id="profile-image1" class="img-circle img-responsive">
                            </div>
                            <h4><center><?php echo Session::get('adminName');?></center></h4>
                            <h5><center>Administrator</center></h5>
                            <br>
                        </div>
                        <a href="admin_index.php" class=" active list-group-item list-group-item-action"><i class="dash-icon fa fa-th" aria-hidden="true"></i>Overview</a>
                        
                         <a href="users.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-users" aria-hidden="true"></i>Users<span class="badge"><?php $userCount = $user->countUsers();if($user){$value=$userCount->fetch_assoc();echo $value['userCount'];}?></span></a>
                        
                        <a href="vehicle.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-car" aria-hidden="true"></i>Vehicles<span class="badge"><?php $vehicleCount = $vehi->countVehicles();if($vehicleCount){$value=$vehicleCount->fetch_assoc();echo $value['vehicleCount'];}?></span></a>
                        
                         <a href="sparePart.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-puzzle-piece" aria-hidden="true"></i>Spare Parts<span class="badge"><?php $sparePartCount = $sp->countspareParts();if($sparePartCount){$value=$sparePartCount->fetch_assoc();echo $value['sparePartCount'];}?></span></a>
                        
                        <a href="orders.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-list-alt" aria-hidden="true"></i>Orders<span class="badge"><?php $bankCount = $br->bankCount();if($bankCount){$value=$bankCount->fetch_assoc();echo $value['bcount'];}?></span></a>
                        
                        <a href="bankLoan.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-university" aria-hidden="true"></i>Bank/Load Details<span class="badge"><?php $bankCount = $br->bankCount();if($bankCount){$value=$bankCount->fetch_assoc();echo $value['bcount'];}?></span></a>
                        
                        <a href="service.php" class="list-group-item list-group-item-action"><i class=" dash-icon fa fa-cogs" aria-hidden="true"></i>Services<span class="badge"><?php $countService = $br->serviceCount();if($countService){$value=$countService->fetch_assoc();echo $value['scount'];}?></span></a>
                        
                    </div>
                    <div class="well progressbarback">
                        <h5>Disk Space Used</h5>
                        <div class="progress">
                              <div class="progress-bar" role="progressbar" style="width: <?= $diskStatus->usedSpace() ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?= $diskStatus->usedSpace() ?>%</div>
                            </div>
               
                    </div>
                        <!--Calander-->
                    
                        <!--End Calender-->
                    
                    
                </div>
                <!--Website Overview-->
                
                <div class="col-md-9">
                    <div class="panel panel-default">
                      <div class="panel-heading main-color">
                        <h3 class="panel-title web-ower">Website Overview</h3>
                      </div>
                      <div class="panel-body">
                          <a href="orders.php">
                          <div class="col-md-3" style="color:#FA8755;">
                            <div class="well carbox">
                                <center><h2><i class="dash-icon fa fa-file-text" aria-hidden="true"></i><span><?php $orderCount = $user->countOrder();if($orderCount){$value=$orderCount->fetch_assoc();echo $value['orderCount'];}?></span></h2>
                                    <h4>Orders</h4></center>
                            </div>
                              
                          </div>
                          </a>
                          <a href="users.php">
                          <div class="col-md-3" style="color:#58D68D;">

                            <div class="well carbox"">
                               <center> <h2><i class="dash-icon fa fa-users" aria-hidden="true"></i><span><?php $userCount = $user->countUsers();if($user){$value=$userCount->fetch_assoc();echo $value['userCount'];}?></span></h2>
                                   <h4>Users</h4></center>
                            </div>

                          </div>
                        </a>
                        <a href="vehicle.php">
                          <div class="col-md-3" style="color:#035BFE;">

                            <div class="well carbox">
                              <center>  <h2><i class="dash-icon fa fa-car" aria-hidden="true"></i><span><?php $vehicleCount = $vehi->countVehicles();if($vehicleCount){$value=$vehicleCount->fetch_assoc();echo $value['vehicleCount'];}?></span></h2>
                                  <h4>Vehicles</h4></center>
                            </div>

                          </div>
                        </a>
                        <a href="bankLoan.php">
                          <div class="col-md-3" style="color:#FE03CD;">

                            <div class="well carbox">
                               <center> <h2><i class=" dash-icon fa fa-bar-chart" aria-hidden="true"></i><span><?php $bankCount = $br->bankCount();if($bankCount){$value=$bankCount->fetch_assoc();echo $value['bcount'];}?></span></h2>
                                   <h4>Bank</h4></center>
                            </div>

                          </div>
                        </a>
                          <hr/>
                        <br/>
                        <h4>Latest Users</h4>
                            <table class="table table-responsive ">
                                <thread>
                                </thread>
                                <tbody>
                                <?php
                                        $getUsers = $user->getLastestUsers();
                                        if($getUsers){
                                            while($result1 = $getUsers->fetch_assoc()){
                                               
                                    ?>
                                                <tr style="text-align: center;"><td><img class="img-circle" src="../<?php echo $result1['image'];?>" height="60px" width="60px"></td>
                                                <td style="padding-top: 25px;"><?php echo $result1['name']?></td>
                                                <td style="padding-top: 25px;"><?php echo $result1['email']?></td>
                                                <td style="padding-top: 25px;"><?php echo $result1['city']?></td>
                                                <td style="padding-top: 25px;"><?php echo $result1['adate']?></td>
                                                </tr>

                                <?php } }?>
                                </tbody>
                            </table>
                    </div>
                </div>
                    <!--Latest Users-->

                </div>
            </div>
        </div>
      </section>
      
      
      <footer id="footer">
        <p>Copyright K.D.T. Japan, &copy; 2017</p>
      </footer>
      <script src="../js/wow.min.js"></script>
    <script>new WOW().init();</script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
      <script src="js/javascript.js" type="text/javascript"></script>
     
      
  </body>
</html>
