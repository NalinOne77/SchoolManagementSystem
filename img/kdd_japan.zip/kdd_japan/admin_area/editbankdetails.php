<?php
ob_start();
    include '../lib/Session.php';
include '../classes/DiskStatus.php';
    Session::checkSession();
    include '../classes/Bank.php';
    include '../classes/User.php';
    include '../classes/Vehicle.php';
    include '../classes/SparePart.php';
    include '../classes/Brand.php';
?>
<?php 
    if(!isset($_GET['bdid']) || $_GET['bdid'] == NULL){
        echo "<script>window.location = 'bankLoan.php';</script>";
     }else{
        $bdid = $_GET['bdid'];
        }
    $ub = new Bank();
    if($_SERVER['REQUEST_METHOD'] == 'POST'){ 
        $Update = $ub->bankUpdate($bank,$bdid);
    }

?>
<?php
try {
  $diskStatus = new DiskStatus('c:');

  $freeSpace = $diskStatus->freeSpace();
  $totalSpace = $diskStatus->totalSpace();
  $barWidth = ($diskStatus->usedSpace()/100) * 400;

} catch (Exception $e) {
  echo 'Error ('.$e->getMessage().')';
  exit();
}
?>
<?php
$user = new User();
$vehi = new Vehicle();
$sp = new SparePart();
$br = new Brand();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Admin Area | Dashborad</title>
      <!--google-font-->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
          <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow" rel="stylesheet">
   
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" >
      <link  href="css/style.css" rel="stylesheet">
      <link  href="css/jquery.simplecolorpicker.css" rel="stylesheet">
      <link  href="css/jquery.simplecolorpicker-fontawesome.css" rel="stylesheet">
      <link  href="css/jquery.simplecolorpicker-glyphicons.css" rel="stylesheet">
      <link  href="css/jquery.simplecolorpicker-regularfont.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css">
  </head>
  <body>
<?php include'header.php'?>
      
      <section id="main">
        <div class="container">
            <div class="row">
                 <div class="col-md-3">
                    <div class="list-group">
                        <div class="header main-color">Dashboard Menu</div>
                        <div style="background-color:white;margin-bottom:-10px">
                            <br>
                            <div  align="center"><img alt="User Pic" src="../images/User.jpg" id="profile-image1" class="img-circle img-responsive">
                            </div>
                            <h4><center><?php echo Session::get('adminName');?></center></h4>
                            <h5><center>Administrator</center></h5>
                            <br>
                        </div>
                        <a href="admin_index.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-th" aria-hidden="true"></i>Overview</a>
                        
                         <a href="users.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-users" aria-hidden="true"></i>Users<span class="badge"><?php $userCount = $user->countUsers();if($user){$value=$userCount->fetch_assoc();echo $value['userCount'];}?></span></a>
                        
                        <a href="vehicle.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-car" aria-hidden="true"></i>Vehicles<span class="badge"><?php $vehicleCount = $vehi->countVehicles();if($vehicleCount){$value=$vehicleCount->fetch_assoc();echo $value['vehicleCount'];}?></span></a>
                        
                         <a href="sparePart.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-puzzle-piece" aria-hidden="true"></i>Spare Parts<span class="badge"><?php $sparePartCount = $sp->countspareParts();if($sparePartCount){$value=$sparePartCount->fetch_assoc();echo $value['sparePartCount'];}?></span></a>

                        <a href="orders.php" class="list-group-item list-group-item-action"><i class="dash-icon fa fa-list-alt" aria-hidden="true"></i>Orders<span class="badge"><?php $bankCount = $br->bankCount();if($bankCount){$value=$bankCount->fetch_assoc();echo $value['bcount'];}?></span></a>
                        
                        <a href="bankLoan.php" class=" active list-group-item list-group-item-action"><i class="dash-icon fa fa-university" aria-hidden="true"></i>Bank/Load Details<span class="badge"><?php $bankCount = $br->bankCount();if($bankCount){$value=$bankCount->fetch_assoc();echo $value['bcount'];}?></span></a>
                        
                        <a href="service.php" class="list-group-item list-group-item-action"><i class=" dash-icon fa fa-cogs" aria-hidden="true"></i>Services<span class="badge"><?php $countService = $br->serviceCount();if($countService){$value=$countService->fetch_assoc();echo $value['scount'];}?></span></a>
                        
                    </div>
                    <div class="well progressbarback">
                        <h5>Disk Space Used</h5>
                        <div class="progress">
                              <div class="progress-bar" role="progressbar" style="width: <?= $diskStatus->usedSpace() ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?= $diskStatus->usedSpace() ?>%</div>
                            </div>
               
                    </div>
                </div>
                <!--Website Overview-->
                
                      <!--Pages-->
                    <div class="col-md-9">
                    <div class="panel panel-default">
                      <div class="panel-heading main-color">
                        <h3 class="panel-title web-ower">Edit Bank Details</h3>
                      </div>
                        <?php if(isset($Update)){echo $Update;}?>
                      <!--Pages-->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-10">
                                    <?php
                                        $getBank = $ub->getBankById($bdid);
                                        if($getBank){
                                            
                                            while($result = $getBank->fetch_assoc()){
                                                
                                    ?>
                                             <form  action="" method="post" class="form-horizontal" enctype="multipart/form-data" autocomplete="off">
                                                 <!--Model-->
                                                <div class="form-group">
                                                    <label for="EngineCap" class="col-sm-3 control-label">Bank</label>
                                                    <div class="col-sm-6">
                                                        <input type="text" name="bank" value="<?php echo $result['bank_Name'];?>" class="form-control">
                                                    </div>
                                                </div>
                                                 
                                                 
                                                 <div class="form-group">
                                                    <label for="Description" class="col-sm-3 control-label ">Interest rate</label>
                                                    <div class="col-sm-3">
                                                        <input type="number" class="form-control tinymce"value="<?php echo $result['interest_Rate'];?>" rows="5" name="irate">
                                                    </div>
                                                </div>
     
                                                     <input name="submit" type="submit" class="btn btn-default"value="Insert">
                                                     <a type="button" href="bankLoan.php"class="btn btn-default">Back</a>
                                            </form>
                                    <?php } } ?>
  
                                </div>
                            </div>
    
                        </div>
                        </div>
                        
                </div>
                
                    <div style="margin-top:20px;">
                </div>
               
                
                
            </div>  
        </div>
      </section>
      <footer id="footer">
        <p>Copyright K.D.T. Japan, &copy; 2017</p>
      </footer>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
      <script src="js/javascript.js"></script>
      <script src="js/jquery.simplecolorpicker.js"></script>
       <script src="js/tinymce/js/tinymce/tinymce.min.js"></script>
      <script>
      $('select[id="colorpicker"]').simplecolorpicker({theme:'fontawesome'});
      </script>
      <script>
          
       window.setTimeout(function() {
            $("#logalert").fadeTo(500, 0).slideUp(500, function(){
                $(this).remove(); 
            });
        }, 4000);
          
        tinymce.init({ selector:'textarea' });  
      </script> 
  </body>
</html>
