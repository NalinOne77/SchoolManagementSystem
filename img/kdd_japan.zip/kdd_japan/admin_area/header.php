 <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
           <div class="navbar-header">
            <button type="button" class="navbar-toggle collapse" data-toggle="collapse" data-target="#navbar" aria-hidden="true">
               <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" href="admin_index.php" style="color:#fff;">K.D.T. Japan</a>
            </div>
            <?php
                if(isset($_GET['action']) && $_GET['action'] == "logout"){
                    Session::destroyadmin();
                }
            ?>
                <div id="navbar" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="inbox.php" style="font-size:16px;margin-right:20px;margin-top:5px;color:#fff">Inbox <span class="badge"><?php $msg = $user->countUnseen();if($msg){$value=$msg->fetch_assoc();echo $value['msgCount'];}?></span></a></li>
                        <div class="btn-group btn-group-info btn-sm">
                            <a style="background-color: #55acee !important;"class="btn btn-info" href="?action=logout"type="button">Logout</a>
                            <a style=" height:34px; background-color: #55acee !important; "data-toggle="dropdown" class="btn btn-info dropdown-toggle btn-sm" type="button">
                              <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                              <li><a href="profile.php">Change Password</a></li>
                            </ul>
                          </div>
                    </ul>
         
                </div>
            
           </div>
      
      </nav>
      
      <header id="header">
        <div class="container">
          <div class="row">
            <div class="col-md-10">
                <h1><i class="dash-icon fa fa-cogs" aria-hidden="true"></i> Dashboard <small id="sm-txt">Manage your site</small></h1>
              </div>
                <div class="col-md-2">
     
                </div>
            </div>
          </div>
      </header>