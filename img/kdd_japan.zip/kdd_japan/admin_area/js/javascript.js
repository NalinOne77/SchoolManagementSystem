



var canvas = document.getElementById("pieChart");
var ctx = canvas.getContext('2d');

// Global Options:
 Chart.defaults.global.defaultFontColor = 'black';
 Chart.defaults.global.defaultFontSize = 16;

var data = {
    labels: ["Users", "Visitors"],
      datasets: [
        {
            fill: true,
            backgroundColor: [
                'cornflowerblue',
                'orange'],
            data: [5, 95],
// Notice the borderColor 
        }
    ]
};

// Notice the rotation from the documentation.

var options = {
        title: {
                  display: true,
                  position: 'top'
              },
        rotation: -0.7 * Math.PI
};


// Chart declaration:
var myBarChart = new Chart(ctx, {
    type: 'pie',
    data: data,
    options: options
});





var ctx = document.getElementById("doughnutChart");
    var donutData = {
    labels: [
        "Honda",
        "Mitsubishi",
        "Toyota",
        "Hyundai",
        "Bmw",
        "Suszuki",
        "Benz",
    ],
    datasets: [
        {
            data: [32, 12,3,55,16,54,22],
            backgroundColor: [
                "#63e779",
                "#fe8687",
                "#6ab9f4",
                "#f5fe05",
                "#fd0eef",
                "#05ddfd",
                "#fd8505",
               
                
            ],
            hoverBackgroundColor: [
                "#41b154",
                "#df3b3c",
                "#1e8bdc",
                "#d7de1a",
                "#e21ad6",
                "#11afc7",
                "#c86d0b",
               
                
            ]
        }]
};


		var donut = new Chart(ctx, {
			type: 'doughnut',
			data: donutData,
			options: {
				cutoutPercentage: 50,
        legend: {
            display: true,
            position: 'top'
			}}
		});




var ctx = document.getElementById("barChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["HNB", "BOC", "Peoples Bank", "DFCC Bank", "Ceylan", "NSB"],
        datasets: [{
            label: 'Interest Rate',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});


/*Calender*/
