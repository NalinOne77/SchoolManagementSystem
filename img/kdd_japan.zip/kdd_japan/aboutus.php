<?php
/**
 * Created by PhpStorm.
 * User: Notebook
 * Date: 10/18/2017
 * Time: 11:36 AM
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>K.D.T. Japan</title>

    <!--google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow" rel="stylesheet">

    <!--CSS-->
    <link href="css/service.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="plugins/font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="css/animate.min.css" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!--start nav bar-->
<div id="nav">
    <div class="navbar navbar-default navbar-fixed-top" data-spy="affix" data-offset-top="100">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img class="img-responsive logo" src="" alt=""><h4>KDD Japan (pvt) Ltd</h4></a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">

                <ul class="nav navbar-nav navbar-right">
                    <li ><a href="index.php">Home</a></li>
                    <li ><a href="showroom.php">Showroom</a> </li>
                    <li ><a href="services.php">Autoservice</a></li>
                    <li><a href="cal.php">Lease</a></li>
                    <li><a href="contactus.php">Contact</a></li>
                    <li class="active"><a href="aboutus.php">About Us</a></li>
                    <?php include 'includes/header.php';?><!-- include Header-->
                </ul>
            </div>
        </div>
    </div>
</div>

<!--End nav bar-->

<div class="jumbotron jum-b" style="background-color:#03a9f4 !important; margin-left:-170px;margin-right:-170px;margin-top:-10px ">
    <div class="container">
        <h1>About Us</h1>
        <p>Feel free to contact us</p>
    </div>
</div>
<section id="main">
    <div class="row">
        <div class="col-md-6" style="padding: 40px;">
            <h3 class="centered-text">A THOUGHTFUL KIND OF CAR COMPANY</h3>
            <p>What would happen if people who were passionate about cars took the time to think about them all over again, as though for the first time?</p>
            <p>What if they cracked the entire industry wide open, peered more deeply into it, spread out all its parts, and questioned their every detail?</p>
            <p>What if they set aside the rules and vowed to discover the things that really matter about a car the things that are universally and undeniably true?</p>
            <p>What if they stood face-to-face with each and every automotive assumption out there and challenged them all with an unprecedented sense of openness and honesty? What kind of answers would they find</p>
            <p>At Hyundai, we ask ourselves the important questions every day. And, every day, we seek the best answers. It’s what makes us grow as a car company. It’s what makes us Hyundai.</p>
            <p>At KDD Japan, we believe in doing good things in the communities in which we do business and operate. Corporate Social Responsibility is not just something we like to do, but it is part of who we are. With every new Hyundai sold in the U.S., money is donated to pediatric cancer research through our signature program Hyundai Hope On Wheels®. In fact, since it began in 1998, Hope On Wheels has awarded over $100 million in grants to children’s hospitals across the country</p>
        </div>
    </div>
</section>

<!--Start footer-->
<?php include 'includes/footer.php';?>

<!--End footer-->

<!--WOW.js-->
<script src="js/wow.min.js"></script>
<script>new WOW().init();</script>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
</body>
</html>
